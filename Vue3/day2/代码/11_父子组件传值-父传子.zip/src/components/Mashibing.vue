<template>
  <div>
    <h1>马士兵教育，我接收到的父组件的值是：{{msbValue}}  {{valueB}}
    {{valueC}}</h1>
  </div>
</template>
<script>
export default {
  // 罗列父组件传进的属性值
  props:{
    msbValue: {
      type: Number,
      // 数据的校验
      validator: function(value) {
        return value > 101
      }
    },
    valueB: Number,
    valueC: Number
  },
  data() {
    return {
      a: 100
    }
  },
  methods:{
    add() {
      this.a ++
    }
  }
}
</script>
<style>
  
</style>