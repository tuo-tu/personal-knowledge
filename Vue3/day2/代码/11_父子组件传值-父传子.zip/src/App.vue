<template>
  <div>
    <Mashibing :msb-value='a' :value-b="b" :value-c="c"></Mashibing>
  </div>
</template>

<script>
// 引入组件
import Mashibing from './components/Mashibing.vue'

export default {
  // 注册组件
  components:{
    Mashibing
  },
  data(){
    return {
      a: 100,
      b: 200,
      c: 300
    }
  }
}
</script>

<style>

</style>
