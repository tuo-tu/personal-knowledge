<template>
  <div>
    <Mashibing></Mashibing>
    <Mashibing></Mashibing>
    <Mashibing></Mashibing>
  </div>
</template>

<script>
// 引入组件
import Mashibing from './components/Mashibing.vue'

export default {
  // 注册组件
  components:{
    Mashibing
  },
  data(){
   
  }
}
</script>

<style>

</style>
